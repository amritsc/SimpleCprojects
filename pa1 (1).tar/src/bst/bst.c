#include <stdio.h>
#include <stdlib.h>

typedef struct _node {
  int data;
  struct _node* left;
  struct _node* right;
} node;

node* insert(int value, node* root) {
  node* prev = NULL, *ptr = root;
  int c = 0;
  while (ptr != NULL) {
    if (value < ptr->data) {
      c = -1;
    } else if (value > ptr->data) {
      c = 1;
    } else {
      c = 0;
    }

    if (c == 0) {
      printf("not inserted\n");
      return root;
    }
    prev = ptr;
    if (c < 0) {
      ptr = ptr->left;
    } else {
      ptr = ptr->right;
    }
  }

  node* new_node = malloc(sizeof(node));
  new_node->data = value;
  new_node->left = NULL;
  new_node->right = NULL;

  if (prev == NULL) {
    root = new_node;
  } else if (c < 0) {
    prev->left = new_node;
  } else {
    prev->right = new_node;
  }
  printf("inserted\n");
  return root;
}

int search(int value, node *root) {
  node *ptr = root;
  int c = 0;
  while (ptr != NULL) {
    if (value < ptr->data) {
      c = -1;
    } else if (value > ptr->data) {
      c = 1;
    } else {
      c = 0;
    }

    if (c == 0) {
      return 1;
    }
    if (c < 0) {
      ptr = ptr->left;
    } else {
      ptr = ptr->right;
    }
  }
  return 0;
}

node *delete(int value, node *root) {
  node *prev = NULL, *ptr = root;
  int c = 0;
  int found = 0;
  while (ptr != NULL) {
    if (value < ptr->data) {
      c = -1;
    } else if (value > ptr->data) {
      c = 1;
    } else {
      c = 0;
    }

    if (c == 0) {
      found = 1;
      break;
    }
    prev = ptr;
    if (c < 0) {
      ptr = ptr->left;
    } else {
      ptr = ptr->right;
    }
  }

  if (!found) {
    printf("absent\n");
    return root;
  }

  node *parent = prev;
  if (ptr->left != NULL && ptr->right != NULL) {
    node *y = ptr->left;
    parent = ptr;
    while (y->right != NULL) {
      parent = y;
      y = y->right;
    }
    ptr->data = y->data;
    ptr = y;
  }
  node *tmp = ptr->right != NULL ? ptr->right : ptr->left;
  if (parent != NULL) {
    if (parent->right == ptr) {
      parent->right = tmp;
    } else {
      parent->left = tmp;
    }
  } else {
    root = tmp;
  }

  printf("deleted\n");
  return root;
}

void print_tree(node* root) {
  if (root == NULL) {
    return;
  }
  printf("(");
  print_tree(root->left);
  printf("%d", root->data);
  print_tree(root->right);
  printf(")");
}

int main(int argc, char** argv) {
  node* root = NULL;

  char type;
  int value;
  while (1) {
    int result = fscanf(stdin, "%c", &type);
    if (result != 1) {
      break;
    }
    if (type == 'i' || type == 's' || type == 'd') {
      int result = fscanf(stdin, "%d", &value);
      if (result != 1) {
	break;
      }
          
      if (type == 'i') {
	root = insert(value, root);
      } else if (type == 's') {
	int there = search(value, root);
	if (there) {
	  printf("present\n");
	} else {
	  printf("absent\n");
	}
      } else if (type == 'd') {
	root = delete(value, root);
      }
    } else if (type == 'p') {
      print_tree(root);
      printf("\n");
    } else {
      continue;
    }
  }
  return 0;
}

