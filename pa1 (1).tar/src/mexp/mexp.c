#include <stdio.h>
#include <stdlib.h>

void MultiplyMatrix(int n, int **A, int **B, int **Product) {
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      int val = 0;
      for (int k = 0; k < n; k++) {
	val += A[i][k] * B[k][j];
      }
      Product[i][j] = val;
    }
  }
}

void CopyMatrix(int n, int **src, int **dest) {
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      dest[i][j] = src[i][j];
    }
  }
}

int main(int argc, char *argv[]) {
  FILE *mexpfile;

  mexpfile = fopen(argv[1], "r");

  if (mexpfile == NULL)
    {
      printf("File is empty");
      printf("\n");
      return 0;
    }

  int n;
  fscanf(mexpfile, "%d", &n);

  int **Matrix = (int **)malloc(n * sizeof(int *));
  int **Temp = (int **)malloc(n * sizeof(int *));
  int **Product = (int **)malloc(n * sizeof(int *));

  for (int a = 0; a < n; a++) {
    Matrix[a] = (int *)malloc(n * sizeof(int));
    Product[a] = (int *)malloc(n * sizeof(int));
    Temp[a] = (int *)malloc(n * sizeof(int));
  }
  for (int a = 0; a < n; a++) {
    for (int b = 0; b < n; b++) {
      Matrix[a][b] = 0;
      Product[a][b] = 0;
      Temp[a][b] = 0;
    }
  }

  for (int i = 0; i < n*n; i++) {
    int x;
    fscanf(mexpfile, "%d", &x);
    Matrix[i/n][i%n] = x;
  }
  CopyMatrix(n, Matrix, Temp);

  int p;
  fscanf(mexpfile, "%d", &p);

  if (p == 0) {
    Product[0][0] = 1;
    Product[1][1] = 1;
    Product[2][2] = 1;
  } else {
    for (int i = 1; i < p; i++) {
      MultiplyMatrix(n, Temp, Matrix, Product);
      CopyMatrix(n, Product, Temp);
    } 
  }

  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      printf("%d", Product[i][j]);
      if (j != n - 1) {
	printf(" ");
      }
    }
    printf("\n");
  }

  for (int i = 0; i < n; i++) {
    free(Matrix[i]);
    free(Temp[i]);
    free(Product[i]);
  }
  free(Matrix);
  free(Temp);
  free(Product);

  fclose(mexpfile);

  return 0;

}
