#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#define SIZE 16384

int main(int argc, char* argv[]){
     	char* input = argv[1];
	int num = atoi(input);
	char output[SIZE];
while (num > 0)
{	
	if (num >= 1000)
	{ 
		strncat(output, "M", 1);
		num -= 1000;
	}
	else if (num >= 900)
	{
		strncat(output, "C", 1);
		strncat(output, "M", 1);
		num -= 900;
	}
	else if (num >= 500)
	{
		strncat(output, "D", 1);
		num -= 500;
	}
	else if (num >= 400)
	{
		strncat(output, "C", 1);
		strncat(output, "D", 1);
		num -= 400;
	}
	else if (num >= 100)
	{
		strncat(output, "C", 1);
		num -= 100;
	}
	else if (num >= 90)
	{
		strncat(output, "X", 1);
		strncat(output, "C", 1);
		num -= 90;
	}
	else if (num >= 50)
	{
		strncat (output, "L", 1);
		num -= 50;
	}
	else if (num >= 40)
	{
		strncat (output, "X", 1);
		strncat (output, "L", 1);
		num -= 40;
	}
	else if (num >= 10)
	{
		strncat (output, "X", 1);
		num -= 10;
	}
	else if (num >= 9)
	{
		strncat (output, "I", 1);
		strncat (output, "X", 1);
		num -= 9;
	}
	else if (num >= 5)
	{
		strncat (output, "V", 1);
		num -= 5;
	}
	else if (num >= 4)
	{
		strncat (output, "I", 1);
		strncat (output, "V", 1);
		num -= 4;
	}
	else if (num >= 1)
	{
		strncat (output, "I", 1);
		num -= 1;
	}
}
printf("%s", output);
printf("\n");
//free(output);
return 0;



}
