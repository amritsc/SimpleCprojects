#include <stdio.h>
#include <stdlib.h>

typedef struct _node {
  struct _node* next;
  int data;
} node;

node* insertValue(int data, node* head) {
  node *prev = NULL, *ptr = head;
  while (ptr != NULL) {
    if (((prev == NULL) || (prev != NULL && prev->data < data))) {
      if (data == ptr->data) {
	return head;
      }
      if (data < ptr->data) {
	break;
      }
    }
    prev = ptr;
    ptr = ptr->next;
  }

  node* new_node = malloc(sizeof(node));
  new_node->data = data;
    
  new_node->next = ptr;
  if (prev != NULL) {
    prev->next = new_node;
  } else {
    head = new_node;
  }

  return head;
}

node* deleteValue(int data, node* head) {
  node* prev = NULL, *ptr = head;
  while (ptr != NULL) {
    if (ptr->data == data) {
      break;
    }
    prev = ptr;
    ptr = ptr->next;
  }
    
  if (ptr != NULL) {
    if (prev == NULL) {
      head = ptr->next;
    } else {
      prev->next = ptr->next;
    }
    free(ptr);
  }
    
  return head;
}

int listSize(node* head) {
  node* ptr = head;
  int size = 0;
  while (ptr != NULL) {
    size++;
    ptr = ptr->next;
  }
  return size;
}

void printList(node* head) {
  node* ptr = head;
  while (ptr != NULL) {
    printf("%d", ptr->data);
    if (ptr->next == NULL) {
      printf("\n");
    } else {
      printf(" ");
    }
    ptr = ptr->next;
  }
}

void freeList(node* head) {
  if (head == NULL) return;
  node* ptr = head;
  while (ptr->next != NULL) {
    node* next = ptr->next;
    free(ptr);
    ptr = next;
  }
  free(ptr);
}

int main(int argc, char** argv) {
  char type;
  int value;

  node* head = NULL;
  while (1) {
    int result = scanf("%c", &type);
    if (result == -1) {
      break;
    }
    result = scanf("%d", &value);
    if (result == -1) {
      break;
    }
    if (type == 'i') {
      if (head == NULL) {
	head = malloc(sizeof(node));
	head->data = value;
	head->next = NULL;
      } else {
	head = insertValue(value, head);
      }
    } else if (type == 'd') {
      head = deleteValue(value, head);
    } else {
      continue;
    }
    int size = listSize(head);
    printf("%d :", size);
    if (size != 0) {
      printf(" ");
    } else {
      printf("\n");
    }
    printList(head);
  }

  freeList(head);
  return 0;
}
