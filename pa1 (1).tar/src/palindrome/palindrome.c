#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<ctype.h>
#define SIZE 16384

int main(int argc, char* argv[]){
	char* input = argv[1];
	int i;
	char clean[SIZE];
	for (i = 0; i < strlen(input); i++)
	{
		if (isalpha(input[i]) != 0)
		{	
			char c = input[i];
			c = tolower(c);
			char babystring[2];    
			babystring[0] = c;
			babystring[1] = '\0';
			strncat(clean, babystring, 1);
		}
	}
	int n = strlen(clean);
	int j;
	char reversed[SIZE];
	for (j = n-1; j >= 0; j--)
	{
		char r = clean[j];
		char babystring2[2];    
		babystring2[0] = r;
		babystring2[1] = '\0';
		strncat(reversed, babystring2, 1);
	}
	if (strcmp(clean, reversed) == 0)
    {
		printf("yes\n");
	}
  	else
	{
  		printf("no\n");
	}
  
	return 0; 
}
