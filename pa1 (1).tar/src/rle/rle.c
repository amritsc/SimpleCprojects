#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<ctype.h>
#define SIZE 16384

int main(int argc, char* argv[])
{
    char* input = argv[1];
    char cuteoutput[SIZE];
    int i;
    for (i = 0; i < strlen(input); i++)
    {
        if (isdigit(input[i]) != 0)
        {
            printf("error");
            return 0;
        }
    }
    int j;
    int counter = 1;
    for (j = 0; j < strlen(input); j++)
    {
        //if(j!=0){j--;}
        counter = 1;
        char c = input[j];
        //printf("%c\n", c);
        while (input[++j] == c)
        {
            counter++;
            //printf("%d\n",j);
        }
        char babystring[2];    
		babystring[0] = c;
		babystring[1] = '\0';
        strncat(cuteoutput, babystring, 1);
        char babystring2[SIZE];
        sprintf(babystring2, "%d", counter);
        //printf("%d",counter);
        //printf("%s", babystring2);
        strncat(cuteoutput, babystring2, strlen(babystring2));
        j--;
    }
    int og = strlen(input);
    int compressed = strlen(cuteoutput);

    if (og > compressed)
    {
        printf("%s", cuteoutput);
        printf("\n");
    }
    else if (og < compressed)
    {
        printf("%s", input);
        printf("\n");
    }
    else if (og == compressed)
    {
        printf("%s", cuteoutput);
        printf("\n");
    }
    return 0;

}